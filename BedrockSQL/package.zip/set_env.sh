export DB_HOST="44.208.103.53"
export DB_USERNAME="diogo"
export DB_PASSWORD='taras!emanias!'
export DB_PORT=5432
export DB_DATABASE="Adventureworks"
export QUESTION="What is the product with the largest amount of items ordered across all sales?"