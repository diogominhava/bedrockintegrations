const express = require('express');
const serverless = require('serverless-http');

const app = express();

app.get('/event', (req, res) => {
  res.json({ message: 'Hello from Express on AWS Lambda!' });
});

app.create('/event', (req, res) => {
    res.json({ message: 'Hello from Express on AWS Lambda!' });
});

app.del('/event', (req, res) => {
    res.json({ message: 'Hello from Express on AWS Lambda!' });
});

module.exports.handler = serverless(app);